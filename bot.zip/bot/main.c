#include "stdlib.h"
#include "Dados.h"
#include "Logica.h"
#include "Interface.h"

int main(int argc, char* argv[]) {
    if (argc == 3) {
        char* filenamea, *filenameb;
        ESTADO *e = inicializa_estado();
        filenamea = argv[1];
        filenameb = argv[2];
        ler(e, filenamea);
        if (fim_de_jogo(e)!=0)
            return 1;
        COORDENADA c = jog(e);
        e = jogar(e, c);
        gravar(e, filenameb);
        free(e);

        return 0;
    } else
    return 0;
}
