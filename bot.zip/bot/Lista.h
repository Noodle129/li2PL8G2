#ifndef PL8_2_LISTA_H
#define PL8_2_LISTA_H

#include "Dados.h"

/**
\brief Tipo de dados para as listas do tipo void*
*/
typedef struct nodo {
    void *valor;
    struct nodo *proximo;
} *LISTA, NODO;

/**
\brief Tipo de dados para as listas de floats
*/

typedef struct nodof {
    float cabeca;
    struct nodof *cauda;
} *LFloat, Nodof;

/**
\brief Funções que trabalham com void*
*/

/**
\brief Função que cria uma lista
 @return Lista vazia
*/
LISTA criar_lista();

/**
\brief Função que insere um valor numa lista
 @param l Lista l
 @param valor Valor a inserir na cabeça
 @return Lista com o valor à cabeça
*/
LISTA insere_cabeca(LISTA l, void *valor);

LFloat snoc (float x, LFloat xs);

/**
\brief Função que devolve a cabeça da lista
 @param l Lista l
 @return A cabeça da lista l
*/
void* devolve_cabeca(LISTA l);

/**
\brief Função que devolve a cauda da lista
 @param l Lista l
 @return Lista que corresponde à cauda da lista l
*/
LISTA proximo(LISTA L);

/**
\brief Função que verifica se a lista está vazia ou não
 @param l Lista l
 @return 1, no caso da lista ser vazia e 0, caso contrário
*/
int lista_esta_vazia(LISTA L);

/**
\brief Função que numa lista, procura um elemento
 @param l Lista l
 @param i o índice (nodo) do elemento que pretendemos obter
 @return o elemento no índice i da lista l
*/
void* procura (LISTA l, int i);

/**
\brief Funções que trabalham com floats
*/

/**
\brief Função que d
 @param l Lista l
 @return a cabeça da lista l
*/

float devolvecabeca(LFloat l);

/**
\brief Função que d
 @param l Lista l
 @param v O valor a inserir em l
 @return Uma lista com v à cabela e l em cauda
*/
LFloat inserecabeca(LFloat l, float v);

/**
\brief Função que d
 @param x valor a ser inserido
 @param xs Lista que será considerada cauda
 @return Lista com o x na cabeça e a lista xs na cauda
*/
LFloat snoc (float x, LFloat xs);

/**
\brief Função que devolve a cauda da lista
 @param l Lista l
 @return Lista que corresponde à cauda da lista l
*/

LFloat proximoF (LFloat l);

#endif
