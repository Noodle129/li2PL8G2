#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

LISTA criar_lista(){
    LISTA novalista;
    novalista = malloc(sizeof(NODO));
    novalista->valor = NULL;
    novalista->proximo = NULL;
    return novalista;
}

LISTA insere_cabeca(LISTA l, void *valor){
    LISTA r = malloc(sizeof(struct nodo));
    r->valor = valor;
    r->proximo = l;
    return r;
}

LFloat snoc (float x, LFloat xs) {
    LFloat pt, ant;

    for (pt = xs; pt != NULL; pt = pt->cauda)
        ant = pt;

    // ant tem o endereço do ultimo nodo da lista
    // pt tem o valor nulo

    pt = malloc (sizeof (Nodof));
    pt->cabeca=x;
    pt->cauda = NULL;

    if (xs == NULL) xs = pt;
    else ant->cauda = pt;

    return xs;
}

// Devolve a cabeça da lista
void* devolve_cabeca(LISTA l){
    void *cabeca;

    if (l == NULL) cabeca = NULL;
    else cabeca = l->valor;

    return cabeca;
}

//Devolve a cauda da lista
LISTA proximo(LISTA L){
    LISTA prox;
    if (L == NULL) prox = NULL;
    else prox = L->proximo;

    return prox;
}

int lista_esta_vazia(LISTA L){
    if (L->valor == NULL && L->proximo == NULL)
        return 1; // ESTÁ VAZIA
    else
        return 0; // NÃO ESTÁ VAZIA
}

void* procura (LISTA l, int i){
    for (; i>0; i--){
        l = proximo(l);
    }

    return devolve_cabeca(l);
}

// FUNÇÕES LINT

float devolvecabeca(LFloat l){
    float cabeca;

    cabeca = l->cabeca;

    return cabeca;
}

LFloat inserecabeca(LFloat l, float v){
    LFloat r = malloc(sizeof(struct nodof));
    r->cabeca = v;
    r->cauda = l;
    return r;
}
/*
LFloat snoc (float x, LFloat xs) {
    LFloat pt, ant;

    for (pt = xs; pt != NULL; pt = pt->cauda)
        ant = pt;

    // ant tem o endereço do ultimo nodo da lista
    // pt tem o valor nulo

    pt = malloc (sizeof (Nodof));
    pt->cabeca=x;
    pt->cauda = NULL;

    if (xs == NULL) xs = pt;
    else ant->cauda = pt;

    return xs;
}
*/
LFloat proximoF (LFloat l){
    LFloat lista;
    if (l == NULL) lista = NULL;
    else lista = l->cauda;

    return lista;
}
