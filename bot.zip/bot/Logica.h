#ifndef PL8_2_LOGICA_H
#define PL8_2_LOGICA_H

#include "Lista.h"

/**
\brief Verifica a validade de uma jogada
 @param e O estado atual do jogo
 @param c Coordenada da jogada
 @returns OK, caso a jogada seja válida e, JOGADA_INVALIDA ,caso contrário
*/
ERRO verifica_jogada(ESTADO *e,COORDENADA c);

/**
\brief Atualiza o estado
 @param e O estado atual do jogo
 @param c A coordenada da última jogada efetuada
*/
void atualiza_estado(ESTADO *e, COORDENADA c);

/**
\brief Função jogar
 @param e O estado atual do jogo
 @param c Coordenada da jogada a efetuar
 @returns O estado atualizado, no caso da jogada ser válida
*/
ESTADO *jogar(ESTADO *e, COORDENADA c);

/**
\brief Testa se o jogo terminou
 @param e O estado atual do jogo
 @returns Um inteiro que corresponde ao jogador que ganha, no caso do jogo terminar ou 0, no caso do jogo não estar concluído
*/
int fim_de_jogo(ESTADO *e);

/**
\brief Verifica se uma coordenada é válida ou não
 @param c A coordenada em teste
 @return OK caso seja válida e COORDENADA_INVÁLIDA caso contrário
*/
ERRO coordenada_valida(COORDENADA c);

/**
\brief Verifica se a peça branca está rodeada de pretas
 @param e O estado atual do jogo
 @returns 1 no caso da peça estar rodeada e 0, caso contrário
*/
int rodeada(ESTADO *e);

/**
\brief Função que devolve uma coordenada a jogar de acordo com eurística do floodfill
 @param e O estado atual do jogo
 @returns A coordenada a jogar
*/
COORDENADA jog(ESTADO *e);

/**
\brief Função que cria lista com coordenadas que rodeiam a coordenada atual
 @param e O estado atual do jogo
 @returns Uma lista de coordenadas possíveis
*/
LISTA cria_lista_rodeada (ESTADO *e);

LFloat distancia (LISTA l, COORDENADA c);

float calculadistancia (COORDENADA a, COORDENADA b);

/**
\brief Função que devolve o menor da lista l
 @param l A lista l
 @returns O valor do menor da lista l
*/
float menor (LFloat l);

/**
\brief Função que procura um elemento numa lista
 @param l A lista na qual vai ser procurado o elemento
 @param n O valor que vai ser procurado
 @returns O índice do elemento na lista
*/
int elem (LFloat l, float n);

/**
\brief Função que analisa se é possível fazer check-mate
 @param e O estado atual do jogo
 @param l Lista de jogadas
 @returns A coordenada em que ocorre o check-mate
*/
COORDENADA check_mate(ESTADO *e,LISTA l);

/**
\brief Função que analisa se o jogador adversário consegue ganhar o jogo
 @param e O estado atual do jogo
 @param c A coordenada a testar
 @returns 1, se o jogador adversário conseguir ganhar e 0, caso contrário e 2, no caso de o jogador estar a suicidar-se
*/
int anticheckmate(ESTADO *e, COORDENADA c);

/**
\brief Função que cria uma lista de coordenadas
 @param tab Um tabuleiro de floats
 @param inicial A coordenada que vai ser testada
 @param valor O valor a ser colocado
 @returns Uma lista de casas para as quais a floodfillaux vai colocar esse valor
*/
LISTA crialistarodeada (TABF* tab, COORDENADA inicial, float valor);

/**
\brief Função que atribui valor a uma casa
 @param e O estado atual do jogo
 @param c A coordenada que vai ser analisada
 @param valor O valor que vai ser atribuido
*/
void set_valor(TABF* tab,COORDENADA c,float v);

/**
\brief Função que converte um tabuleiro para um tabuleiro de floats
 @param e O estado atual do jogo
 @param casa_objetivo A casa à qual o jogador pretende chegar de forma a vencer o jogo
 @param O tabuleiro com os valores atribuídos
*/
TABF* converte_tabuleiro (ESTADO *e,int casa_objetivo);

/**
\brief Função que cria uma lista de coordenadas
 @param e O estado do jogo
 @returns Uma lista com os valores em torno da peça branca
*/
LFloat floodfill(ESTADO* e);

/**
\brief Função que atribui valores float a todas as casas do tabuleiro
 @param tab Um tabuleiro de floats
 @param l A lista das coordenadas a que pode atribuir valores
 @param valor O valor a ser colocado
*/
void floodfill_aux(TABF *tab,LISTA l,float valor);

#endif
