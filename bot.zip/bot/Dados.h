/**
\brief Definição de dados
*/

#ifndef PL8_2_DADOS_H
#define PL8_2_DADOS_H

/**
\brief Tipo de dados para a casa
*/
typedef enum {
    UM = '1',
    DOIS = '2',
    VAZIO = '.',
    BRANCA = '*',
    PRETA = '#'
} CASA;

/**
\brief Tipo de dados para a coordenada
*/
typedef struct {
    int coluna;
    int linha;
} COORDENADA;

/**
\brief Tipo de dados para a jogada
*/
typedef struct {
    COORDENADA jogador1;
    COORDENADA jogador2;
} JOGADA;

/**
\brief Tipo de dados para o array de jogadas
*/
typedef JOGADA JOGADAS[32];

/**
\brief
*/
typedef struct {
    /** O tabuleiro */
    CASA tab[8][8];
    /** As jogadas */
    JOGADAS jogadas;
    /** O número das jogadas, usado no prompt */
    int num_jogadas;
    /** O jogador atual */
    int jogador_atual;
    /** O nº de comando, usado no prompt */
    int num_comando;
    /** A coordenada da última jogada */
    COORDENADA ultima_jogada;
} ESTADO;

/**
\brief Tipo de dados para os erros
*/
typedef enum {
    OK,
    COORDENADA_INVALIDA,
    JOGADA_INVALIDA,
    ERRO_LER_TAB,
    ERRO_ABRIR_FICHEIRO,
    ERRO_GRAVAR
} ERRO;

/**
\brief Tipo de dados para um tabuleiro de floats
*/
typedef float TABF[8][8];

/**
\brief Declaração de funções
*/

/**
\brief Devolve a coordenada, tendo em conta que as linhas são contadas de forma inversa.
*/
COORDENADA converte_coordenada(COORDENADA c);

/**
\brief Atribui a todas as jogadas dos jogadores a COORDENADA nula = {-1,-1}.
*/
void clear_jogadas(ESTADO *e);

/**
\brief Inicializa o estado
 @returns O estado inicial do jogo, tendo em conta todos os parâmetros do estado.
*/
ESTADO *inicializa_estado();

/**
\brief Devolve o jogador atual
 @param estado O estado atual do jogo
 @returns O jogador atual
*/
int obter_jogador_atual(ESTADO *estado);

/**
\brief Devolve o número de jogadas
 @param estado O estado atual do jogo
 @returns O número de jogadas efetuadas
*/
int obter_numero_de_jogadas(ESTADO *estado);

/**
\brief Devolve o estado da casa
 @param estado O estado atual do jogo
 @param c Coordenada da casa
 @returns O estado da casa de coordenada c
*/
CASA obter_estado_casa(ESTADO *e, COORDENADA c);

/**
\brief Devolve o última jogada efetuada
 @param estado O estado atual do jogo
 @returns A coordenada da última jogada efetuada
*/
COORDENADA obter_ultima_jogada(ESTADO *estado);

/**
\brief Devolve o número de comandos
 @param estado O estado atual do jogo
 @returns O número de comandos efetuados
*/
int obter_num_comandos(ESTADO *estado);

/** brief Traduz a linha em char
 @param c A coordenada a traduzir
 @returns Um char com a linha traduzida de acordo com o tabuleiro
 */
char traduz_linha(COORDENADA c);

/** brief Traduz a coluna em char
 @param c A coordenada a traduzir
 @returns Um char com a coluna traduzida de acordo com o tabuleiro
 */
char traduz_coluna(COORDENADA c);

/** brief Devolve a coordenada de uma jogada
 @param e O estado do jogo
 @param j O jogador que efetuou a jogada
 @param nj O número da jogada que se pretende devolver
 @returns A coordenada da jogada nj do jogador j
 */
COORDENADA obter_coordjogada(ESTADO *e, int nj, int j);

/**
\brief Modifica uma casa
 @param e O estado atual do jogo
 @param c A coordenada a modificar
 @param peca O caracter que vai ser interpretado
 @param casa O estado da casa
*/
void set_casa(ESTADO *e,COORDENADA c,char peca);

/**
\brief Atualiza o tabuleiro
 @param e O estado atual do jogo
 @param c A coordenada da jogada
*/
void atualiza_tabuleiro(ESTADO *e, COORDENADA c);

/**
\brief Atualiza o número de jogadas
 @param e O estado atual do jogo
 @param nj O número de jogadas do estado e
*/
void atualiza_numero_jogadas(ESTADO *e, int nj);

/**
\brief Atualiza jogador
 @param e O estado atual do jogo
 @param ja O jogador atual
*/
void atualiza_jogador(ESTADO *e,int ja);

/**
\brief Atualizada jogadas
 @param e O estado atual do jogo
 @param nj O número de jogadas
 @param O jogador atual
 @param c Coordenada da jogada a adicionar
*/
void atualiza_jogadas(ESTADO *e,COORDENADA c,int nj,int ja);

/**
\brief Atualiza a ultima jogada
 @param e O estado atual do jogo
 @param c A coordenada da última jogada efetuada
*/
void atualiza_ultima_jogada(ESTADO *e,COORDENADA c);

/**
\brief Atualiza a jogada
 @param e O estado atual do jogo
 @param nj A jogada a atualizar
 @param j1 A coordenada a colocar no jogador1
 @param j2 A coordenada a colocar no jogador2
*/
void set_jogadas(ESTADO *e, int nj,COORDENADA j1,COORDENADA j2);

#endif
