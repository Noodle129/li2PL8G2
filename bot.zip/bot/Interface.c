#include <stdio.h>
#include <string.h>
#include "Dados.h"
#include "Interface.h"

#define BUF_SIZE 1024

void movs (ESTADO *e, FILE *fp) {
    int jogada = obter_numero_de_jogadas(e);
    for (int i = 0; i <= jogada; i++) {
        // Jogada Jogador 1
        COORDENADA j1 = obter_coordjogada(e,i,1);
        char j1l = traduz_linha(j1), j1c = traduz_coluna(j1);

        // Jogada Jogador 2
        COORDENADA j2 = obter_coordjogada(e,i,2);
        char j2l = traduz_linha(j2), j2c = traduz_coluna(j2);

        if (obter_jogador_atual(e) == 2 && i == obter_numero_de_jogadas(e)) {
            fprintf(fp, "%02d:", i+1);
            fprintf(fp, " %c%c\n", j1c, j1l);
        }
        else
        if(obter_jogador_atual(e) == 1 && i == obter_numero_de_jogadas(e)){

        }else{
            fprintf(fp, "%02d:", i+1);
            fprintf(fp, " %c%c %c%c\n", j1c, j1l, j2c, j2l);
        }
    }
}

//Função que grava o estado do tabuleiro num ficheiro
ERRO gravar(ESTADO *e, char *fn) {
    FILE *fp;
    fp = fopen(fn, "w+");
    if (fp == NULL )
        return ERRO_GRAVAR;
    else {
        for (int i = 0; i < 8 ; i++) {
            for (int j = 0; j < 8; j++) {
                COORDENADA c = {j, i};
                CASA casa = obter_estado_casa(e, c);
                fprintf(fp, "%c", casa);
            }
            fprintf(fp, "\n");
        }
        fprintf(fp, "\n");
        movs(e,fp);

    }
    fclose(fp);
    return OK;

}

ERRO ler_tabuleiro(ESTADO *e, FILE* fp){
    char a[BUF_SIZE];
    COORDENADA c = {-1,-1};
    if (fp == NULL)
        return ERRO_ABRIR_FICHEIRO;
    else {
        for (c.linha = 0; c.linha < 8 && fgets(a,BUF_SIZE,fp); c.linha++) {
            for (c.coluna = 0; c.coluna < 8; c.coluna++) {
                set_casa(e,c,a[c.coluna]);
                    if(a[c.coluna] == '*')
                        atualiza_ultima_jogada(e,c);
            }
        }
        if(fgets(a,BUF_SIZE,fp)){}
        }
    return OK;
}

ERRO ler_jogadas(ESTADO *e,FILE *fp){
    clear_jogadas(e);
    int nj = 0, ja = 1, l1, l2, nv;
    char c1[2], c2[2];
    while ((nv = (fscanf(fp, "%02d: %c%d %c%d", &nj, c1, &l1, c2, &l2))) != EOF) {
        COORDENADA j1= {*c1 - 'a', l1 - 1}, j2 = {*c2 - 'a', l2 - 1};
        COORDENADA nula = {-1,-1};
        j1 = converte_coordenada(j1);
        j2 = converte_coordenada(j2);
        if (nv == 5) {
            set_jogadas(e,nj,j1,j2);
            ja = 1;
            nj++;
        }else{
            set_jogadas(e,nj,j1,nula);
            ja = 2;
        }
    }
    if (nj == 0) {
        atualiza_numero_jogadas(e, 0);
    }
    else {
        atualiza_numero_jogadas(e, nj - 1);
    }
    atualiza_jogador(e,ja);

    fclose(fp);
    return OK;
}

ERRO ler (ESTADO *e, char *fn){
    FILE *fp;
    fp = fopen(fn,"a+");
    char a[BUF_SIZE];
    while (fgets(a,BUF_SIZE,fp) != NULL);
    fseek(fp,0,SEEK_SET);
    ler_tabuleiro(e,fp);
    ler_jogadas(e,fp);
    return OK;
}
