#ifndef PL8_2_INTERFACE_H
#define PL8_2_INTERFACE_H
#include <stdio.h>

/**
\brief Comando movs
 @param e O estado atual do jogo
 @param fp O ficheiro em que vai ser usado o movs
*/
void movs (ESTADO *e, FILE *fp);

/**
\brief Comando gravar
 @param e O estado atual do jogo
 @param filename O nome do ficheiro em que vai ser guardado o ficheiro
 @returns ERRO_GRAVAR no caso de não ser possível gravar o ficheiro e OK, caso contrário.
*/
ERRO gravar(ESTADO *e, char *filename);

/**
\brief Comando ler
 @param e O estado atual do jogo
 @param filename O nome do ficheiro a ser lido
 @returns OK, no caso do ficheiro ser lido
*/
ERRO ler(ESTADO *e, char *filename);

#endif
