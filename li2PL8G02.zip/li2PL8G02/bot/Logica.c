#include <stdlib.h>
#include "Dados.h"
#include "Logica.h"
#include "Lista.h"
#include <time.h>
#include <math.h>

#define BUF_SIZE 1024

ERRO verifica_jogada(ESTADO *e,COORDENADA c)
{
    COORDENADA uj = obter_ultima_jogada(e);
    int col = c.coluna;
    int l = c.linha;
    int minl = uj.linha - 1;
    int maxl = uj.linha + 1;
    int minc = uj.coluna - 1;
    int maxc = uj.coluna + 1;

    if (obter_estado_casa(e,c) == VAZIO || obter_estado_casa(e,c) == UM || obter_estado_casa(e,c) == DOIS) {
        if ((col >= minc) && (col <= maxc) && (l >= minl) && (l <= maxl)) {
            return OK;
        } else {
            return JOGADA_INVALIDA;
        }
    } else{
        return JOGADA_INVALIDA;
    }
}

void atualiza_estado(ESTADO *e, COORDENADA c)
{
    int nj = obter_numero_de_jogadas(e);
    int ja = obter_jogador_atual(e);
    atualiza_jogadas(e,c,nj,ja);
    if (ja == 1){
        ja = 2;
        atualiza_jogador(e,ja);
    }else{
        ja = 1;
        atualiza_jogador(e,ja);
        nj++;
        atualiza_numero_jogadas(e,nj);
    }
    atualiza_jogadas(e,c,nj,ja);
    atualiza_tabuleiro(e,c);
    atualiza_ultima_jogada(e,c);
}

ESTADO *jogar(ESTADO *e, COORDENADA c) {
    ERRO validade = verifica_jogada(e,c);
    if(validade==OK) {
        atualiza_estado(e,c);
    }
    return e;
}

int fim_de_jogo(ESTADO *e) {
    COORDENADA c = {0,7};
    CASA a = obter_estado_casa(e,c); // Casa 1
    c.coluna = 7;
    c.linha = 0;
    CASA b = obter_estado_casa(e,c); // Casa 2

    if (a == BRANCA ) {
        return 1;
    }

    if (b == BRANCA) {
        return 2;
    }

    if (rodeada(e)==1) {
        int j = obter_jogador_atual(e);
        if (j == 1) j=2;
        else j = 1;
        return j;
    }
    else return 0; // Não termina o jogo
}

ERRO coordenada_valida(COORDENADA c)
{
    ERRO verificacao;
    int col = c.coluna;
    int l = c.linha;

    verificacao = (col >= 0 && col < 8 && l >= 0 && l < 8)? OK : COORDENADA_INVALIDA;
    return verificacao;
}

int erro_floodfill(LFloat l){
    while (l){
        if (l->cabeca > 0)
            return 0;//floodfill ainda funciona
        l = l->cauda;
    }
    return 1; //floodfill não funciona mais
}

int rodeada(ESTADO *e){
    COORDENADA uj = obter_ultima_jogada(e);
    COORDENADA c = uj;
    int linha, coluna;

    for (linha = -1; linha <=1; linha++) {
        for (coluna = -1; coluna <=1 ; ++coluna) {
            c.linha = uj.linha + linha;
            c.coluna = uj.coluna + coluna;
            if(c.coluna == uj.coluna && c.linha == uj.linha);
            else if(coordenada_valida(c) == OK){
                if (obter_estado_casa(e,c) != '#')
                    return 0; //não se encontra rodeada.
            }
        }
    }
    return 1; //encontra-se rodeada.
}

COORDENADA jog(ESTADO *e) {
    LISTA l = cria_lista_rodeada(e);
    ESTADO *tentativa = inicializa_estado();
    *tentativa = *e;
    COORDENADA c,anti_suicida, nula = {-1, -1},a = {-1,-1}, cm = check_mate(e, l);

    if (cm.coluna != nula.coluna && cm.linha != nula.linha) c = cm;

    else {
        LFloat lista = floodfill(e);
        int i, ef = erro_floodfill(lista);
        if (ef == 1){
            if (obter_jogador_atual(e)==1) {
                a.coluna = 0; a.linha = 7;
            } else{
                a.coluna = 7; a.linha = 0;
            }
            LFloat lista = distancia(l, a);
            i = elem(lista, menor(lista));
            c = *(COORDENADA *) procura(l, i);

        } else {
            float teste_m = menor(lista);
            i = elem(lista, teste_m);
            c = *(COORDENADA *) procura(l, i);
        }
        while (anticheckmate(tentativa, c)!=0) {
            set_casa(tentativa, c, PRETA);
            l = cria_lista_rodeada(tentativa);
            if (lista_esta_vazia(l) == 1) return c;
            if (ef == 1)
                lista = distancia(l, a);
            else
                lista = floodfill(tentativa);
            i = elem(lista, menor(lista));
            anti_suicida = *((COORDENADA *) procura(l, i));
            if (anticheckmate(tentativa, anti_suicida)==2){
                set_casa(tentativa, anti_suicida, PRETA);
            }else{
                c = anti_suicida;
            }
        }
    }
    return c;
}

LISTA cria_lista_rodeada (ESTADO *e) {
    COORDENADA uj = obter_ultima_jogada(e);
    LISTA l = criar_lista();

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            COORDENADA* t = malloc(sizeof(COORDENADA));
            t->coluna = uj.coluna + j;
            t->linha = uj.linha + i;

            if (coordenada_valida(*t) == OK)
            {
                if (obter_estado_casa(e, *t) == VAZIO || obter_estado_casa(e, *t) == UM || obter_estado_casa(e, *t) == DOIS) {
                    l = insere_cabeca(l, t);
                }
            }
        }
    }

    return l;
}

LFloat distancia (LISTA l, COORDENADA c){
    LFloat lista = NULL;

    while (l->valor != NULL)
    {
        COORDENADA a = *((COORDENADA*) l->valor);
        float d = calculadistancia(a, c);
        lista = snoc(d,lista);
        l = proximo(l);
    }

    return lista;
}

float calculadistancia (COORDENADA a, COORDENADA b){
    int colA = a.coluna, lA = a.linha, colB = b.coluna, lB = b.linha;
    float distancia;
    distancia = sqrtf(pow(colB - colA, 2) + (powf(lB - lA, 2)));

    return distancia;
}

float menor (LFloat l){
    float menor ;
    menor = l->cabeca;
    while(l != NULL){
        if (l->cabeca < menor) {
            menor = l->cabeca;
            l = proximoF(l);
        }

        else l = proximoF(l);
    }

    return menor;
}

int elem (LFloat l, float n)
{
    int i = 0;

    while (l){

        if ((devolvecabeca(l)) == n)
        {
            return i;
        }

        else{
            l = proximoF(l);
            i++;
        }
    }

    return i;
}

COORDENADA check_mate(ESTADO *e,LISTA l) {
    int fdj, ja;
    COORDENADA c;
    ESTADO *tentativa = inicializa_estado();
    COORDENADA nula = {-1, -1};

    while (devolve_cabeca(l) != NULL) {
        *tentativa = *e;
        ja = obter_jogador_atual(e);
        c = *(COORDENADA *) l->valor;
        jogar(tentativa, c);
        fdj = fim_de_jogo(tentativa);
        if (fdj == 0 || fdj!=ja) {
            l = l->proximo;
        } else if (ja == fdj) {
            return c; //faz cheque-mate
        }
    }

    return nula;
}

int anticheckmate(ESTADO *e, COORDENADA c){
    ESTADO *tentativa = inicializa_estado();
    *tentativa = *e;
    jogar(tentativa,c);
    if (fim_de_jogo(tentativa))
        return 2;
    LISTA l = cria_lista_rodeada(tentativa);
    COORDENADA nula = {-1,-1};
    COORDENADA cm = check_mate(tentativa,l);

    if (cm.linha == nula.linha && cm.coluna == nula.coluna)
    {
        return 0; // pode jogar
    }
    else return 1; // não pode jogar
}

// FUNÇOES DA FLOODFILL

LISTA crialistarodeada (TABF* tab, COORDENADA inicial, float valor) {
    LISTA l = NULL;

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            COORDENADA* t = malloc(sizeof(COORDENADA));
            t->coluna = inicial.coluna + j;
            t->linha = inicial.linha + i;
            float casa = *tab[t->linha][t->coluna];
            if (coordenada_valida(*t) == OK)
            {
                if (casa == -1 || casa>valor) {
                    l = insere_cabeca(l, t);
                }
            }
        }
    }

    return l;
}

void set_valor(TABF* tab,COORDENADA c,float v){
    *tab[c.linha][c.coluna] = v;
}

TABF* converte_tabuleiro (ESTADO *e,int casa_objetivo){
    COORDENADA c;
    CASA casa;
    TABF* tabuleiro = malloc(sizeof(TABF));
    float valor1 = -1, valor2 = -1;
    if(casa_objetivo==1){
        valor1 = 0;
    }
    else if (casa_objetivo==2) {
        valor2 = 0;
    }
    for (c.linha = 0; c.linha <8 ; c.linha++) {
        for (c.coluna = 0; c.coluna < 8 ; c.coluna++) {
            casa = obter_estado_casa(e, c);
            switch (casa) {
                case '.':
                    set_valor(tabuleiro, c, -1);
                    break;
                case '#':
                    set_valor(tabuleiro, c, -2);
                    break;
                case '*':
                    set_valor(tabuleiro, c, -1);
                    break;
                case '1':
                    set_valor(tabuleiro, c, valor1);
                    break;
                case '2':
                    set_valor(tabuleiro, c, valor2);
                    break;
                default:
                    set_valor(tabuleiro, c, -1);
            }
        }
    }

    return tabuleiro;
}

LFloat cria_LFloat_rodeada(TABF* tab, COORDENADA c){
    COORDENADA teste;
    LFloat r = NULL;
    for (teste.linha = -1; teste.linha <= 1; teste.linha++) {
        for (teste.coluna = -1; teste.coluna <= 1; teste.coluna++) {
            COORDENADA coordenada = {-1, -1};
            coordenada.coluna = teste.coluna + c.coluna;
            coordenada.linha = teste.linha + c.linha;
            if (coordenada.linha == c.linha && coordenada.coluna == c.coluna);
            else{
                float casa = *tab[coordenada.linha][coordenada.coluna];
                if (casa >= -1 && coordenada_valida(coordenada) == OK)
                    r = inserecabeca(r, casa);
            }
        }
    }
    return r;
}

LFloat floodfill(ESTADO* e){
    int ja = obter_jogador_atual(e);
    TABF* tab = converte_tabuleiro(e,ja);
    COORDENADA inicial;
    if(ja==1) {
        inicial.linha = 7;inicial.coluna = 0;
    }else{
        inicial.linha = 0;inicial.coluna = 7;
    }
    float valor = 1;
    LISTA l = crialistarodeada(tab,inicial,valor);
    floodfill_aux(tab,l,valor);
    COORDENADA branca = obter_ultima_jogada(e);
    LFloat r = cria_LFloat_rodeada(tab,branca);
    return r;
}

void floodfill_aux(TABF *tab,LISTA l,float valor){
    while (l) {
        COORDENADA testa = *(COORDENADA*) l->valor;
        set_valor(tab,testa,valor);
        LISTA next = crialistarodeada(tab,testa,valor);
        floodfill_aux(tab,next,valor+1);
        l = l->proximo;
    }
}
