# Projeto_LI2
Laboratórios de Informática 2 --  2019-2020

Projeto de implementação, em linguagem C, do jogo "Rastros" no âmbito da UC de Laboratórios de Informática II da Universidade do Minho

Grupo 2 - PL8

Projeto desenvolvido por:

Lídia Anaís Coelho de Sousa A93205

António Ricardo Vieira da Fonseca A93167

João Luis Tibo Machado dos Santos A93235
