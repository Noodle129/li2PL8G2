#ifndef PL8_2_LOGICA_H
#define PL8_2_LOGICA_H

#include "Lista.h"

/**
\brief Verifica se uma coordenada é válida ou não
 @param c A coordenada em teste
 @return OK caso seja válida e COORDENADA_INVÁLIDA caso contrário
*/
ERRO coordenada_valida(COORDENADA c);

/**
\brief Verifica a validade de uma jogada
 @param e O estado atual do jogo
 @param c Coordenada da jogada
 @returns OK, caso a jogada seja válida e, JOGADA_INVALIDA ,caso contrário
*/
ERRO verifica_jogada(ESTADO *e,COORDENADA c);

/**
\brief Atualiza o estado
 @param e O estado atual do jogo
 @param c A coordenada da última jogada efetuada
*/
void atualiza_estado(ESTADO *e, COORDENADA c);

/**
\brief Função jogar
 @param e O estado atual do jogo
 @param c Coordenada da jogada a efetuar
 @returns O estado atualizado, no caso da jogada ser válida
*/
ESTADO *jogar(ESTADO *e, COORDENADA c);

/**
\brief Testa se o jogo terminou
 @param e O estado atual do jogo
 @returns Um inteiro que corresponde ao jogador que ganha, no caso do jogo terminar ou 0, no caso do jogo não estar concluído
*/
int fim_de_jogo(ESTADO *e);

/**
\brief Comando pos
 @param e O estado atual do jogo
 @param jogada A jogada para o qual o pos remete
 @return o estado do jogo na jogada para a qual se remete
*/
ESTADO *pos(ESTADO *e,int jogada);

/**
\brief Verifica se a peça branca está rodeada de pretas
 @param e O estado atual do jogo
 @returns 1 no caso da peça estar rodeada e 0, caso contrário
*/
int rodeada(ESTADO *e);

/**
\brief Função que joga de forma aleatória
 @param e O estado atual do jogo
 @returns A coordenada a jogar
*/
COORDENADA jogaleatoria (ESTADO *e);

/**
\brief Função que devolve uma coordenada a jogar de acordo com eurística da distância euclidiana
 @param e O estado atual do jogo
 @returns A coordenada a jogar
*/
COORDENADA jog(ESTADO *e);

/**
\brief Função que cria lista com coordenadas que rodeiam a coordenada atual
 @param e O estado atual do jogo
 @returns Uma lista de coordenadas possíveis
*/
LISTA cria_lista_rodeada (ESTADO *e);

/**
\brief Função que cria lista com a distância de cada coordenada da lista l até à coordenada c
 @param l Lista da qual vão ser retiradas as coordenasas
 @param c Coordenada para a qual a distância vai ser avaliada
 @returns Uma lista de distâncias das coordenadas
*/
LFloat distancia (LISTA l, COORDENADA c);

/**
\brief Função que calcula a distância entre 2 coordenadas
 @param a Coordenada a
 @param b Coordenada b
 @returns A distância entre a e b
*/
float calculadistancia (COORDENADA a, COORDENADA b);

/**
\brief Função que devolve o menor da lista l
 @param l A lista l
 @returns O valor do menor da lista l
*/
float menor (LFloat l);

/**
\brief Função que procura um elemento numa lista
 @param l A lista na qual vai ser procurado o elemento
 @param n O valor que vai ser procurado
 @returns O índice do elemento na lista
*/
int elem (LFloat l, float n);

/**
\brief Função que analisa se é possível fazer check-mate
 @param e O estado atual do jogo
 @param l Lista de jogadas
 @returns A coordenada em que ocorre o check-mate
*/
COORDENADA check_mate(ESTADO *e,LISTA l);

/**
\brief Função que analisa se o jogador adversário consegue ganhar o jogo
 @param e O estado atual do jogo
 @param c A coordenada a testar
 @returns 1, se o jogador adversário conseguir ganhar e 0, caso contrário
*/
int anticheckmate(ESTADO *e, COORDENADA c);

/**
\brief Função que gera um número aleatório
 @param lower O limite mínimo do número a gerar
 @param upper O limite máximo do número a gerar
 @param count O número de aleatórios a gerar
 @returns O número gerado
*/
int randomNs(int lower, int upper, int count);

#endif
