/**
\brief Definição de listas
*/

#ifndef PL8_2_LISTA_H
#define PL8_2_LISTA_H

#include "Dados.h"

/** @struct nodo
 * @brief Struct dos componentes de uma lista de void*
 * @var nodo::valor
 * O endereço da cabeça da lista
 * @var nodo::proximo
 * O endereço para o resto da lista
*/
typedef struct nodo {
    void *valor;
    struct nodo *proximo;
} *LISTA, NODO;

/** @struct nodof
 * @brief Struct dos componentes de uma lista de floats
 * @var nodof:: cabeca
 * A cabeça da lista de floats
 * @var nodof::cauda
 * A cauda da lista
*/
typedef struct nodof {
    float cabeca;
    struct nodof *cauda;
} *LFloat, Nodof;

/**
\brief Funções que trabalham com void*
*/

/**
\brief Função que cria uma lista
 @return Lista vazia
*/
LISTA criar_lista();

/**
\brief Função que insere um valor numa lista
 @param l Lista l
 @param *valor Valor a inserir na cabeça
 @return Lista com o valor à cabeça
*/
LISTA insere_cabeca(LISTA l, void *valor);

/**
\brief Função que devolve a cabeça da lista
 @param l Lista l
 @return A cabeça da lista l
*/
void* devolve_cabeca(LISTA l);

/**
\brief Função que devolve a cauda da lista
 @param L Lista
 @return Lista que corresponde à cauda da lista l
*/
LISTA proximo(LISTA L);

/**
\brief Função que remove a cabeça de uma lista, libertando o espaço da cabeça
 @param L Lista l
 @return Lista l sem a cabeça
*/
LISTA remove_cabeca(LISTA L);

/**
\brief Função que verifica se a lista está vazia ou não
 @param L Lista l
 @return 1, no caso da lista ser vazia e 0, caso contrário
*/
int lista_esta_vazia(LISTA L);

/**
\brief Função que numa lista, procura um elemento com um índice
 @param l Lista l
 @param i o índice (nodo) do elemento que pretendemos obter
 @return o elemento no índice i da lista l
*/
void* procura (LISTA l, int i);

/**
\brief Função que calcula o tamanho da lista
 @param l Lista l
 @return O tamanho da lista
*/
int length(LISTA l);

/**
\brief Função que liberta o espaço de uma lista
 @param l Lista l
*/
void freeList (LISTA l);

/**
\brief Funções que trabalham com floats
*/

/**
\brief Função que devolve a cabeça de uma lista de floats
 @param l Lista l
 @return A cabeça da lista l
*/

float devolvecabeca(LFloat l);

/**
\brief Função que insere um valor à cabeça de uma lista
 @param l Lista l
 @param v O valor a inserir em l
 @return Uma lista com v à cabela e l em cauda
*/

LFloat inserecabeca(LFloat l, float v);

/**
\brief Função que insere um valor no final de uma lista
 @param x valor a ser inserido
 @param xs Lista que será considerada cauda
 @return Lista com o x na cabeça e a lista xs na cauda
*/
LFloat snoc (float x, LFloat xs);

/**
\brief Função que remove a cabeça de uma lista
 @param l Lista l
 @return Lista l sem o valor anteriormente posicionado na cabeça
*/
LFloat removecabeca(LFloat l);

/**
\brief Função que devolve a cauda da lista
 @param l Lista l
 @return Lista que corresponde à cauda da lista l
*/
LFloat proximoF (LFloat l);

#endif
