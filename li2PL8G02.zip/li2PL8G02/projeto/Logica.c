#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "Dados.h"
#include "Logica.h"
#include "Lista.h"
#include <math.h>
#include <time.h>

#define BUF_SIZE 1024

ERRO coordenada_valida(COORDENADA c)
{
    ERRO verificacao;
    int col = c.coluna;
    int l = c.linha;

    verificacao = (col >= 0 && col < 8 && l >= 0 && l < 8)? OK : COORDENADA_INVALIDA;
    return verificacao;
}

ERRO verifica_jogada(ESTADO *e,COORDENADA c)
{
    COORDENADA uj = obter_ultima_jogada(e);
    int col = c.coluna;
    int l = c.linha;
    int minl = uj.linha - 1;
    int maxl = uj.linha + 1;
    int minc = uj.coluna - 1;
    int maxc = uj.coluna + 1;

    if (obter_estado_casa(e,c) == VAZIO || obter_estado_casa(e,c) == UM || obter_estado_casa(e,c) == DOIS) {
        if ((col >= minc) && (col <= maxc) && (l >= minl) && (l <= maxl)) {
            return OK;
        } else {
            return JOGADA_INVALIDA;
        }
    } else{
        return JOGADA_INVALIDA;
    }
}

void atualiza_estado(ESTADO *e, COORDENADA c)
{
    int nj = obter_numero_de_jogadas(e);
    int ja = obter_jogador_atual(e);
    atualiza_jogadas(e,c,nj,ja);
    if (ja == 1){
        ja = 2;
        atualiza_jogador(e,ja);
    }else{
        ja = 1;
        atualiza_jogador(e,ja);
        nj++;
        atualiza_numero_jogadas(e,nj);
    }
    atualiza_jogadas(e,c,nj,ja);
    atualiza_tabuleiro(e,c);
    atualiza_ultima_jogada(e,c);
}

ESTADO *jogar(ESTADO *e, COORDENADA c) {
    ERRO validade = verifica_jogada(e,c);
    if(validade==OK) {
        atualiza_estado(e,c);
    }
    return e;
}

int fim_de_jogo(ESTADO *e) {
    COORDENADA c = {0,7};
    CASA a = obter_estado_casa(e,c); // Casa 1
    c.coluna = 7;
    c.linha = 0;
    CASA b = obter_estado_casa(e,c); // Casa 2

    if (a == BRANCA ) {
        return 1;
    }

    if (b == BRANCA) {
        return 2;
    }

    if (rodeada(e)==1) {
        int j = obter_jogador_atual(e);
        if (j == 1) j=2;
        else j = 1;
        return j;
    }
    else return 0; // Não termina o jogo
}

ESTADO *pos(ESTADO *e, int jogada)
{
    int i;
    ESTADO *n_estado;
    n_estado = inicializar_estado();

    for (i = 0; i <jogada ; i++) {
        COORDENADA j1 = e->jogadas[i].jogador1;
        COORDENADA j2 = e->jogadas[i].jogador2;
        jogar(n_estado,j1);
        jogar(n_estado,j2);
    }
    return n_estado;
}

int rodeada(ESTADO *e){
    COORDENADA uj = obter_ultima_jogada(e);
    COORDENADA c = uj;
    int linha, coluna;

    for (linha = -1; linha <=1; linha++) {
        for (coluna = -1; coluna <=1 ; ++coluna) {
            c.linha = uj.linha + linha;
            c.coluna = uj.coluna + coluna;
            if(c.coluna == uj.coluna && c.linha == uj.linha);
            else if(coordenada_valida(c) == OK){
                if (obter_estado_casa(e,c) != '#')
                    return 0; //não se encontra rodeada.
            }
        }
    }
    return 1; //encontra-se rodeada.
}

COORDENADA jogaleatoria (ESTADO *e){
    LISTA l;
    l = cria_lista_rodeada(e);
    int lower = 0, upper = length(l) - 1, count = 1, r;
    printf("Length: %d \n", length(l));
    srand(time(NULL));
    r = randomNs(lower, upper, count);
    printf(" r : %d \n", r);
    COORDENADA c;

    c = *(COORDENADA*) procura(l,r);

    return c;
}

COORDENADA jog(ESTADO *e) {
    LISTA l = cria_lista_rodeada(e);
    ESTADO *tentativa = inicializar_estado();
    *tentativa = *e;
    int jogador = obter_jogador_atual(e);
    COORDENADA c, nula = {-1, -1}, a = {-1,-1}, cm = check_mate(e, l);

    if (cm.coluna != nula.coluna && cm.linha != nula.linha) c = cm;

    else {
        if (jogador == 1) {
            a.coluna = 0;
            a.linha = 7;
        } else {
            a.coluna = 7;
            a.linha = 0;
        }

        LFloat lista = distancia(l, a);
        int i = elem(lista, menor(lista));
        c = *(COORDENADA *) procura(l, i);

        while (anticheckmate(tentativa, c)) {
            set_casa(tentativa, c, PRETA);
            l = cria_lista_rodeada(tentativa);
            if (lista_esta_vazia(l) == 0) return c;
            lista = distancia(l, a);
            i = elem(lista, menor(lista));
            c = *((COORDENADA *) procura(l, i));
        }

    }

    return c;
}

LISTA cria_lista_rodeada (ESTADO *e) {
    COORDENADA uj = obter_ultima_jogada(e);
    LISTA l = criar_lista();

    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            COORDENADA* t = malloc(sizeof(COORDENADA));
            t->coluna = uj.coluna + j;
            t->linha = uj.linha + i;

            if (coordenada_valida(*t) == OK)
            {
                if (obter_estado_casa(e, *t) == VAZIO || obter_estado_casa(e, *t) == UM || obter_estado_casa(e, *t) == DOIS) {
                    l = insere_cabeca(l, t);
                }
            }
        }
    }

    return l;
}

LFloat distancia (LISTA l, COORDENADA c){
    LFloat lista = NULL;

    while (l->valor != NULL)
    {
        COORDENADA a = *((COORDENADA*) l->valor);
        float d = calculadistancia(a, c);
        lista = snoc(d,lista);
        l = proximo(l);
    }

    return lista;
}

float calculadistancia (COORDENADA a, COORDENADA b){
    int colA = a.coluna, lA = a.linha, colB = b.coluna, lB = b.linha;
    float distancia;
    distancia = sqrtf(pow(colB - colA, 2) + (powf(lB - lA, 2)));

    return distancia;
}

float menor (LFloat l){
    COORDENADA a = {0,7};// Coordenada 1
    COORDENADA b = {7,0};// Coordenada 2
    float maiordistancia = calculadistancia(a,b);
    float menor = maiordistancia;

    while(l != NULL){

        if (l->cabeca < menor) {
            menor = l->cabeca;
            l = proximoF(l);
        }

        else l = proximoF(l);
    }

    return menor;
}

int elem (LFloat l, float n)
{
    int i = 0;

    while (l != NULL){

        if ((devolvecabeca(l)) == n)
        {
            return i;
        }

        else{
            l = proximoF(l);
            i++;
        }
    }

    return i;
}

COORDENADA check_mate(ESTADO *e,LISTA l) {
    int fdj, ja;
    COORDENADA c;
    ESTADO *tentativa = inicializar_estado();
    COORDENADA nula = obter_ultima_jogada(e);
    nula.linha = -1;
    nula.coluna = -1;
    if(l->valor != NULL) {
        *tentativa = *e;
        ja = obter_jogador_atual(e);
        c = *(COORDENADA *) l->valor;
        jogar(tentativa, c);
        fdj = fim_de_jogo(tentativa);
        if (fdj == 0 || fdj!=ja) {
            l = proximo(l);
        } else if (ja == fdj) {
            return c; //faz cheque-mate
        }
    }

    return nula;
}

int anticheckmate(ESTADO *e, COORDENADA c){
    ESTADO *tentativa = inicializar_estado();
    *tentativa = *e;
    jogar(tentativa,c);
    LISTA l = cria_lista_rodeada(tentativa);
    COORDENADA nula = {-1,-1};
    COORDENADA cm = check_mate(tentativa,l);

    if (cm.linha == nula.linha && cm.coluna == nula.coluna)
    {
        return 0; // pode jogar
    }
    else return 1; // não pode jogar
}

int randomNs(int lower, int upper, int count)
{
    int i, num = -1;
    for (i = 0; i < count; i++)
    {
        num = (rand() %
               (upper - lower + 1)) + lower;
    }
    return num;
}
