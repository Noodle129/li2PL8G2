/**
\brief Definição da Interface
*/

#ifndef PL8_2_INTERFACE_H
#define PL8_2_INTERFACE_H
#include <stdio.h>

/**
\brief Imprime a peça com o símbolo associado à casa
 @param c A casa
 @param fp O ficheiro em que vai ser imprimida a peça
*/
void imprimePeca(CASA c, FILE *fp);

/**
\brief Imprime o erro, mostrando uma frase associada ao erro ocorrido
 @param e O erro
 @param fp O ficheiro em que vai ser imprimido o erro
*/
void imprimeErro (ERRO e, FILE *fp);

/**
\brief Devolve o tabuleiro
 @param e O estado atual do jogo
 @param fp O ficheiro em que vai ser imprimido o tabuleiro
*/
void mostrar_tabuleiro(ESTADO *e, FILE *fp);

/**
\brief Função que mostra tudo relativamente ao estado
 @param e O estado atual do jogo
 @param fp O ficheiro em que vão ser imprimidas as informações
*/
void mostra_estado(ESTADO *e,FILE *fp);

/**
\brief Devolve o prompt
 @param e O estado atual do jogo
 @param fp O ficheiro em que vai ser usado o prompt
*/
void prompt (ESTADO *e, FILE *fp);

/**
\brief Comando movs
 @param e O estado atual do jogo
 @param fp O ficheiro em que vai ser usado o movs
*/
void movs (ESTADO *e, FILE *fp);

/**
\brief Comando gravar
 @param e O estado atual do jogo
 @param filename O nome do ficheiro em que vai ser guardado o ficheiro
 @returns ERRO_GRAVAR no caso de não ser possível gravar o ficheiro e OK, caso contrário.
*/
ERRO gravar(ESTADO *e, char *filename);

/**
\brief Função que lê o tabuleiro de um ficheiro
 @param e O estado atual do jogo
 @param fp O ficheiro que vai ser lido
 @returns OK, no caso do ficheiro ser lido e ERRO_ABRIR_FICHEIRO, caso contrário
*/
ERRO ler_tabuleiro(ESTADO *e, FILE* fp);

/**
\brief Função que lê as jogadas de um ficheiro
 @param e O estado atual do jogo
 @param fp O ficheiro a ser lido
 @returns OK no caso das jogadas serem lidas
*/
ERRO ler_jogadas(ESTADO *e,FILE *fp);

/**
\brief Função que lê o ficheiro
 @param e O estado atual do jogo
 @param fn O nome do ficheiro a ser lido
 @returns OK no caso do ficheiro ser lido
*/
ERRO ler (ESTADO *e, char *fn);

/**
\brief Interpretador
 @param e O estado atual do jogo
 @returns 1 no caso de o jogo ter terminado e 0 caso contrário
*/
int interpretador(ESTADO *e);

#endif
