#include <stdio.h>
#include <string.h>
#include "Dados.h"
#include "Logica.h"
#include "Interface.h"

#define BUF_SIZE 1024

void imprimePeca(CASA c, FILE *fp){
    fprintf(fp,"%c ",c);
}

void imprimeErro (ERRO e, FILE *fp){
    if (e == ERRO_ABRIR_FICHEIRO)
        fprintf(fp, "Erro a abrir ficheiro");
    else if (e == OK)
        fprintf(fp, "OK");
    else if (e == ERRO_LER_TAB)
        fprintf(fp, "Erro a ler tabuleiro");
    else if (e == COORDENADA_INVALIDA)
        fprintf(fp, "Introduzida coordenada inválida");
    else if (e == JOGADA_INVALIDA)
        fprintf(fp, "Jogada inválida");
}

void mostrar_tabuleiro(ESTADO *e, FILE *fp) {
    int i, j;
    for (i = 0; i < 8 ; i++) {
        int linha = 8 - i;
        fprintf(fp, "%d ",linha);
        for (j = 0; j < 8; j++) {
            COORDENADA c = {j, i};
            CASA casa = obter_estado_casa(e,c);
            imprimePeca(casa, fp);
        }
        fprintf(fp, "\n");
    }
    fprintf(fp, "  A B C D E F G H \n");
}

void mostra_estado(ESTADO *e,FILE *fp){
    mostrar_tabuleiro(e,fp);
    prompt(e,fp);
    movs(e,fp);
}

void prompt (ESTADO *e, FILE *fp){
    COORDENADA uj = obter_ultima_jogada(e);
    fprintf(fp,"Número de Jogadas : %d   Número de Comandos : %d\n",obter_numero_de_jogadas(e),obter_num_comandos(e));
    fprintf(fp,"Última Jogada : %c%c      Jogador Atual : %d\n",traduz_coluna(uj),traduz_linha(uj),obter_jogador_atual(e));
}


void movs (ESTADO *e, FILE *fp) {
    int jogada = obter_numero_de_jogadas(e);
    for (int i = 0; i <= jogada; i++) {
        // Jogada Jogador 1
        COORDENADA j1 = obter_coordjogada(e,i,1);
        char j1l = traduz_linha(j1);
        char j1c = traduz_coluna(j1);

        // Jogada Jogador 2
        COORDENADA j2 = obter_coordjogada(e,i,2);
        char j2l = traduz_linha(j2);
        char j2c = traduz_coluna(j2);

        if (obter_jogador_atual(e) == 2 && i == obter_numero_de_jogadas(e)) {
            if(i+1 < 10)
                fprintf(fp, "0%d:", i+1);
            else
                fprintf(fp, "%d:", i+1);
            fprintf(fp, " %c%c\n", j1c, j1l);

        }
        else
        if(obter_jogador_atual(e) == 1 && i == obter_numero_de_jogadas(e)){

        }else {
            if(i+1 < 10)
                fprintf(fp, "0%d:", i+1);
            else
                fprintf(fp, "%d:", i+1);
            fprintf(fp, " %c%c %c%c\n", j1c, j1l, j2c, j2l);
        }
    }
}

//Função que grava o estado do tabuleiro num ficheiro
ERRO gravar(ESTADO *e, char *fn) {
    FILE *fp;
    fp = fopen(fn, "w+");
    if (fp == NULL)
        return ERRO_GRAVAR;
    else {
        for (int i = 0; i < 8 ; i++) {
            for (int j = 0; j < 8; j++) {
                COORDENADA c = {j, i};
                CASA casa = obter_estado_casa(e, c);
                fprintf(fp, "%c", casa);
            }
            fprintf(fp, "\n");
        }
        fprintf(fp, "\n");
        movs(e,fp);

    }
    fclose(fp);
    return OK;

}

ERRO ler_tabuleiro(ESTADO *e, FILE* fp){
    char a[BUF_SIZE];
    COORDENADA c = {-1,-1};
    if (fp == NULL)
        return ERRO_ABRIR_FICHEIRO;
    else {
        for (c.linha = 0; c.linha < 8 && fgets(a,BUF_SIZE,fp); c.linha++) {
            for (c.coluna = 0; c.coluna < 8; c.coluna++) {
                set_casa(e,c,a[c.coluna]);
                if(a[c.coluna] == '*')
                    atualiza_ultima_jogada(e,c);
            }
        }
        if(fgets(a,BUF_SIZE,fp)){}
    }
    return OK;
}

ERRO ler_jogadas(ESTADO *e,FILE *fp){
    clear_jogadas(e);
    int nj = 0, ja = 1, l1, l2, nv;
    char c1[2], c2[2];
    while ((nv = (fscanf(fp, "%02d: %c%d %c%d", &nj, c1, &l1, c2, &l2))) != EOF) {
        COORDENADA j1= {*c1 - 'a', l1 - 1}, j2 = {*c2 - 'a', l2 - 1};
        COORDENADA nula = {-1,-1};
        j1 = converte_coordenada(j1);
        j2 = converte_coordenada(j2);
        if (nv == 5) {
            set_jogadas(e,nj,j1,j2);
            ja = 1;
            nj++;
        }else{
            set_jogadas(e,nj,j1,nula);
            ja = 2;
        }
    }
    atualiza_numero_jogadas(e,nj-1);
    atualiza_jogador(e,ja);

    fclose(fp);
    return OK;
}

ERRO ler (ESTADO *e, char *fn){
    FILE *fp;
    fp = fopen(fn,"a+");
    char a[BUF_SIZE];
    while (fgets(a,BUF_SIZE,fp) != NULL);
    fseek(fp,0,SEEK_SET);
    ler_tabuleiro(e,fp);
    ler_jogadas(e,fp);
    return OK;
}



int interpretador(ESTADO *e)
{
    mostrar_tabuleiro(e, stdout);
    printf("  ---------------\n");
    prompt(e, stdout);
    COORDENADA c;

    COMANDO ultimo_comando = JOGAR;
    ESTADO *estado_pos = NULL;

    while(fim_de_jogo(e)==0)
    {
        char linha[BUF_SIZE];
        char col[2], lin[2];
        char filename[4];
        int jogada;
        ERRO erro;

        if (fgets(linha, BUF_SIZE, stdin) == NULL)
            return 0;

        else if (strlen(linha) == 3 && sscanf(linha, "%[a-h]%[1-8]", col, lin) == 2)
        {
            fprintf(stdout,"Introduza uma nova jogada\n");
            COORDENADA coord = {*col - 'a', *lin - '1'};
            coord = converte_coordenada(coord);
            if (ultimo_comando == POS) {
                *e = *estado_pos;
            }
            e = jogar(e, coord);
            printf("Jogar %d %d\n", coord.coluna, coord.linha);
            ultimo_comando = JOGAR;
            atualiza_num_comando(e,obter_num_comandos(e)+1);
            mostrar_tabuleiro(e, stdout);
            prompt(e, stdout);
        }

        else if (sscanf(linha, "gr %s", filename) == 1) {
            if ((erro = gravar(e, filename)) == OK) {
                gravar(e, filename);
                fprintf(stdout, "Ficheiro guardado com sucesso.\n");
                ultimo_comando = GRAVAR;
                atualiza_num_comando(e,obter_num_comandos(e)+1);
            } else
                imprimeErro(erro, stdout);
        }

        else if (sscanf(linha, "ler %s", filename) == 1) {
            if ((erro = ler(e, filename)) == OK) {
                ler(e, filename);
                atualiza_num_comando(e,obter_num_comandos(e)+1);
                mostrar_tabuleiro(e, stdout);
                prompt(e, stdout);
                fprintf(stdout, "Ficheiro lido com sucesso.\n >>");
                ultimo_comando = LER;
            }else
                imprimeErro(erro, stdout);
        }

        else if (strcmp(linha, "movs\n") == 0) {
                movs(e,stdout);
                fprintf(stdout,"Comando movs executado com sucesso.\n");
                ultimo_comando = MOVS;
                atualiza_num_comando(e,obter_num_comandos(e)+1);
        }

        else if (sscanf(linha, "pos %d", &jogada) == 1) {
            int ja = obter_numero_de_jogadas(e);
            if (jogada > ja)
                fprintf(stdout, "Jogada %d ainda não realizada.\n", jogada);
            else {
                estado_pos = pos(e, jogada);
                ultimo_comando = POS;
                atualiza_num_comando(e,obter_num_comandos(e)+1);
                mostrar_tabuleiro(estado_pos,stdout);
            }
        }

        else if (strcmp(linha, "jog1\n") == 0){
            c = jogaleatoria(e);
            if (ultimo_comando == POS)
            {
                *e = *estado_pos;
            }
            jogar(e, c);
            mostrar_tabuleiro(e, stdout);
            prompt(e,stdout);
            ultimo_comando = JOG;
            atualiza_num_comando(e,obter_num_comandos(e)+1);
        }

        else if (strcmp(linha, "jog2\n") == 0){
            c = jog(e);
            if (ultimo_comando == POS)
            {
                *e = *estado_pos;
            }
            jogar(e, c);
            mostrar_tabuleiro(e, stdout);
            prompt(e,stdout);
            ultimo_comando = JOG;
            atualiza_num_comando(e,obter_num_comandos(e)+1);
        }

        else if(strcmp(linha, "mostra estado\n") == 0){
            mostra_estado(e,stdout);
        }

        else if (strcmp(linha, "Q\n") == 0) {
            fprintf(stdout,"Até à próxima!");
            return 0;
        }
    }

    fprintf(stdout, "Parabéns Jogador %d, você venceu!!", fim_de_jogo(e));

    return 1;
}
