#include "Dados.h"
#include <stdlib.h>

COORDENADA converte_coordenada(COORDENADA c){
    c.linha = 7 - c.linha;
    return c;
}

void clear_jogadas(ESTADO *e){
    int i;
    COORDENADA cnula = {-1,-1};
    JOGADA jnula = {cnula,cnula};

    for (i = 0; i < 32; i++) {
        e->jogadas[i] = jnula;
    }
}

ESTADO *inicializar_estado()
{
    ESTADO *estadoinicial;
    estadoinicial = malloc(sizeof(ESTADO));
    int i, j;

    CASA tabuleiro[8][8] = {{VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, DOIS},
                            {VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO},
                            {VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO},
                            {VAZIO, VAZIO, VAZIO, VAZIO, BRANCA, VAZIO, VAZIO, VAZIO},
                            {VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO},
                            {VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO},
                            {VAZIO, VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO},
                            {UM,    VAZIO, VAZIO, VAZIO, VAZIO,  VAZIO, VAZIO, VAZIO}};
    for (i = 0; i<8 ; i++) {
        for (j = 0; j<8 ; j++) {
            estadoinicial->tab[i][j] = tabuleiro[i][j];
        }
    }
    COORDENADA uj = {4,3};
    estadoinicial->ultima_jogada = uj;
    clear_jogadas(estadoinicial);
    estadoinicial->num_jogadas = 0;
    estadoinicial->jogador_atual = 1;
    estadoinicial->num_comando = 00;
    return estadoinicial;
}

int obter_jogador_atual(ESTADO *estado){
    return estado->jogador_atual;
}

int obter_numero_de_jogadas(ESTADO *estado){
    return estado->num_jogadas;
}

COORDENADA obter_ultima_jogada(ESTADO *estado){
    return estado->ultima_jogada;
}

CASA obter_estado_casa(ESTADO *e, COORDENADA c){
    return e->tab[c.linha][c.coluna];
}

int obter_num_comandos(ESTADO *estado){
    return estado->num_comando;
}

char traduz_linha(COORDENADA c) {
    int linha = 7 - c.linha;

    char l = '1';

    l += linha;

    return l;
}

char traduz_coluna(COORDENADA c){
    int coluna = c.coluna;

    char col = 'a';

    col += coluna;

    return col;

}

COORDENADA obter_coordjogada(ESTADO *e, int nj, int j)
{
    COORDENADA jogada;
    if (j == 1){
        jogada = e->jogadas[nj].jogador1;
    }
    else
        jogada = e->jogadas[nj].jogador2;

    return jogada;
}

void set_casa(ESTADO *e, COORDENADA c, char peca){
    switch(peca){
        case '.':
            e->tab[c.linha][c.coluna] = VAZIO;
            break;
        case '#':
            e->tab[c.linha][c.coluna] = PRETA;
            break;
        case '*':
            e->tab[c.linha][c.coluna] = BRANCA;
            break;
        case '1':
            e->tab[c.linha][c.coluna] = UM;
            break;
        case '2':
            e->tab[c.linha][c.coluna] = DOIS;
            break;
        default:
            e->tab[c.linha][c.coluna] = VAZIO;
    }
}

// Função que atualiza o tabuleiro conforme a coordenada da jogada
void atualiza_tabuleiro(ESTADO *e, COORDENADA c)
{
    COORDENADA uj = e->ultima_jogada;
    int col = uj.coluna;
    int l = uj.linha;

    e->tab[l][col] = PRETA;
    e->tab[c.linha][c.coluna]=BRANCA;
}

// Função que atualiza o número de jogadas
void atualiza_numero_jogadas(ESTADO *e, int nj)
{
    e->num_jogadas = nj;
}

// Função que atualiza o jogador atual
void atualiza_jogador(ESTADO *e,int ja)
{
    e->jogador_atual = ja;
}

// Função que atualiza jogadas de cada jogador
void atualiza_jogadas(ESTADO *e,COORDENADA c,int nj,int ja) {
    if (ja == 1) {
        e->jogadas[nj].jogador1 = c;
    } else{
        e->jogadas[nj].jogador2 = c;
    }
}

// Função que atualiza o número de comandos efetuados
void atualiza_num_comando(ESTADO *e,int nc)
{
    e->num_comando = nc;
}

// Função que atualiza a última jogada que foi feita
void atualiza_ultima_jogada(ESTADO *e,COORDENADA c)
{
    e->ultima_jogada = c;
}

void set_jogadas(ESTADO *e, int nj,COORDENADA j1,COORDENADA j2){
    nj--;
    e->jogadas[nj].jogador1 = j1;
    e->jogadas[nj].jogador2 = j2;
}
